valReal = float(input("Digite um valor em R$: "))
print(valReal,"R$")

dolAm = valReal*0.1756759
print("O valor convertido é ", dolAm)

euro = valReal*0.1616449
print("O valor convertido é ", euro)

pesoAr = valReal*188.4658877
print("O valor convertido é ", pesoAr)

libraEst = valReal*0.1353949
print("O valor convertido é ", libraEst)

iene = valReal*26.3435195
print("O valor convertido é ", iene)