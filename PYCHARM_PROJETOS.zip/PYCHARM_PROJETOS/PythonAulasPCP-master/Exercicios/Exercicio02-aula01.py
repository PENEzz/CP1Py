faren = int(input("Qual a temp em F: "))



celcius= faren/32 * 5/9

print("A temp em C:", celcius)