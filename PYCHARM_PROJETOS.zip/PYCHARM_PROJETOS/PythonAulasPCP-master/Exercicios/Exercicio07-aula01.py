qtdPeca1 = int(input("Qual a qtd de peças? "))
valPeca1 = float(input("Qual o valor unitário da peça? "))

qtdPeca2 = int(input("Qual a qtd de peças? "))
valPeca2 = float(input("Qual o valor unitário da peça? "))

total = (qtdPeca1*valPeca1) + (qtdPeca2*valPeca2)

print("O total a ser pago é ", total)