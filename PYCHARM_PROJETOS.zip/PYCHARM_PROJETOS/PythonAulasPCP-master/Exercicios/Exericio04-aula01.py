vel = 60
dist = 150
temp = dist/vel

print("O trajeto durou ", temp)