raio = 5
print(raio)

area = 3.14159 * raio**2

print(area)