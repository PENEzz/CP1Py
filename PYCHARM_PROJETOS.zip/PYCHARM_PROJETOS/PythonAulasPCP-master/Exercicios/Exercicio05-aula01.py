nota1 = int(input("A 1ra nota do aluno foi: "))
nota2 = int(input("A 2nda nota do aluno foi: "))

mediaArit = (nota1+nota2) / 2

print("A média aritmética é ", mediaArit)