valProd = float(input("Qual o valor? "))
valPag = float(input("Quanto foi pago? "))

troco = valPag - valProd

print("O troco é: ", troco)