livroVal = 25
canetaVal = 5

valTotal = livroVal*3 + canetaVal*2

print("O valor total gasto foi de", valTotal)