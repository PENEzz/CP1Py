num1 = int(input("Digite o primeiro num: "))
num2 = int(input("Digite o segundo num: "))

print(num1 + num2)