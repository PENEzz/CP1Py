dia = input("Dia do nascimento: ")
mes = input("Mês do nascimento: ")
ano = input("Ano do nascimento: ")

print(f"{dia}/{mes}/{ano}")