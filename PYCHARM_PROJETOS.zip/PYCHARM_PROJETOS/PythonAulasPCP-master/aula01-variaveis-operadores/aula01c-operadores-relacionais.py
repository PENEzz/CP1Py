print(6 == 2)
print(6 != 2)

idade = 20

print(idade == 10)
print(idade != 10)

logado = True
print(logado)

maior_idade = idade >= 18
print(maior_idade)

nome1 = "Marcos"
nome2 = "marcos"

print(nome1 == nome2)