num1 = 5
num2 = 2

print(type(num1), type(num2))

soma = num1 + num2
print("Soma: ", soma, type(soma)    )

subtracao = num1 - num2
print("Sub: ", subtracao, type(subtracao))

multiplicacao = num1 * num2
print("Multiplicação: ", multiplicacao, type(multiplicacao))

divisao = num1 / num2
print("Divisão: ", divisao, type(divisao))

#-------------------------------------------------------------

div_inteira = num1 // num2
print("Divisão Int: ", div_inteira, type(div_inteira))

resto = num1 % num2
print("Resto: ", resto, type(resto))

potencia = num1 ** num2
print("Potência: ", potencia, type(potencia))


# Operadores de Atribuição
num = 15
print()
print(num)

num += 2
print(num)

num -= 10
print(num)